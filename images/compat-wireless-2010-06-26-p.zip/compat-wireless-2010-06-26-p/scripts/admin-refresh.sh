#!/bin/bash
./scripts/admin-clean.sh $@
./scripts/admin-update.sh $@
